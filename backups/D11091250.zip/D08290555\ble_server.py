#!/usr/bin/env python3
"""
════════════════════════════════════════════════════════════
ble_server.py  —  bless 기반 BLE GATT 서버 (NUS 프로토콜)

패킷 프로토콜
  웹 → 라즈베리파이 (RX):
      [0xAA, axis_code, direction, pwm, 0x55]  ← 모터 명령
      [0xBB, axis_code, 0x55]                  ← 엔코더 요청
      axis_code: 0x01=J1, 0x02=J2, 0x03=J3

  라즈베리파이 → 아두이노 (Serial):
      "F,150\n" / "B,100\n" / "S,0\n"

  라즈베리파이 → 웹 (TX notify):
      [0xCC, axis_code, raw_H, raw_L, 0x55]    ← 엔코더 응답
════════════════════════════════════════════════════════════
"""

import asyncio
import logging
import threading
import time
import sys
import serial
import serial.tools.list_ports

from bless import BlessServer, BlessGATTCharacteristic, GATTCharacteristicProperties, GATTAttributePermissions

log = logging.getLogger('BLE_SERVER')

NUS_SERVICE_UUID = '6e400001-b5a3-f393-e0a9-e50e24dcca9e'
NUS_RX_UUID      = '6e400002-b5a3-f393-e0a9-e50e24dcca9e'
NUS_TX_UUID      = '6e400003-b5a3-f393-e0a9-e50e24dcca9e'

PKT_MOTOR_CMD = 0xAA
PKT_ENC_REQ   = 0xBB
PKT_ENC_RSP   = 0xCC
PKT_TAIL      = 0x55

AXIS_MAP  = {0x01: 'j1', 0x02: 'j2', 0x03: 'j3'}
AXIS_CODE = {'j1': 0x01, 'j2': 0x02, 'j3': 0x03}

# ── 터미널 컬러 ──────────────────────────────────────────
C_RESET  = '\033[0m'
C_CYAN   = '\033[96m'
C_GREEN  = '\033[92m'
C_YELLOW = '\033[93m'
C_RED    = '\033[91m'
C_PURPLE = '\033[95m'
C_BOLD   = '\033[1m'
C_DIM    = '\033[2m'


# ══════════════════════════════════════════════════════════
# 터미널 대시보드
# ══════════════════════════════════════════════════════════
class TerminalDashboard:
    def __init__(self):
        self._state = {
            'j1': {'pwm': 0, 'dir': 0, 'enc_raw': 0, 'enc_deg': 0.0, 'enc_connected': False},
            'j2': {'pwm': 0, 'dir': 0, 'enc_raw': 0, 'enc_deg': 0.0, 'enc_connected': False},
            'j3' : {'pwm': 0, 'dir': 0, 'enc_raw': 0, 'enc_deg': 0.0, 'enc_connected': False},
        }
        self._arduino = {
            'j1': {'connected': False, 'port': '—'},
            'j2': {'connected': False, 'port': '—'},
            'j3' : {'connected': False, 'port': '—'},
        }
        self._ble_connected = False
        self._lock = threading.Lock()
        self._running = False
        self._last_cmd_axis = '—'
        self._last_cmd_dir  = '—'
        self._last_cmd_pwm  = 0

    def start(self):
        self._running = True
        sys.stdout.write('\033[?25l')
        sys.stdout.flush()
        if getattr(self, '_thread', None) and self._thread.is_alive(): return
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False
        thread = getattr(self, '_thread', None)
        if thread and thread is not threading.current_thread(): thread.join(timeout=0.5)
        sys.stdout.write('\033[?25h\n')
        sys.stdout.flush()

    def update_motor(self, axis, direction, pwm):
        with self._lock:
            if axis in self._state:
                self._state[axis]['pwm'] = pwm
                self._state[axis]['dir'] = direction
                self._last_cmd_axis = axis.upper()
                self._last_cmd_dir  = 'FWD' if direction == 1 else ('STOP' if pwm == 0 else 'BWD')
                self._last_cmd_pwm  = pwm

    def update_encoder(self, axis, raw, deg, connected=True):
        with self._lock:
            if axis in self._state:
                self._state[axis]['enc_raw'] = raw
                self._state[axis]['enc_deg'] = deg
                self._state[axis]['enc_connected'] = connected

    def set_ble(self, connected):
        with self._lock:
            self._ble_connected = connected

    def set_arduino(self, axis, connected, port='—'):
        with self._lock:
            if axis in self._arduino:
                self._arduino[axis]['connected'] = connected
                self._arduino[axis]['port'] = port

    def _loop(self):
        print('\033[2J\033[H', end='')
        while self._running:
            self._render()
            time.sleep(0.1)

    def _render(self):
        with self._lock:
            state   = {k: dict(v) for k, v in self._state.items()}
            arduino = {k: dict(v) for k, v in self._arduino.items()}
            ble_ok  = self._ble_connected
            last_axis = self._last_cmd_axis
            last_dir  = self._last_cmd_dir
            last_pwm  = self._last_cmd_pwm

        out = '\033[H'
        W = 60

        def bar(val, maxv=255, width=18):
            filled = max(0, min(width, int(val / maxv * width)))
            return C_GREEN + '█' * filled + C_DIM + '░' * (width - filled) + C_RESET

        def dir_str(d, pwm):
            if pwm == 0: return C_DIM + ' STOP ' + C_RESET
            return (C_GREEN + '▶ FWD ' + C_RESET) if d == 1 else (C_YELLOW + '◀ BWD ' + C_RESET)

        ble_dot = C_GREEN + '●' + C_RESET if ble_ok else C_RED + '○' + C_RESET

        out += f"{C_BOLD}{C_CYAN}╔{'═'*W}╗{C_RESET}\n"
        out += f"{C_BOLD}{C_CYAN}║{C_RESET}{'  SCARA ROBOT  —  3축 실시간 모니터':^{W}}{C_BOLD}{C_CYAN}║{C_RESET}\n"
        out += f"{C_BOLD}{C_CYAN}╠{'═'*W}╣{C_RESET}\n"

        ble_label = f"BLE {ble_dot} {'연결됨' if ble_ok else '대기중'}"
        out += f"{C_BOLD}{C_CYAN}║{C_RESET}  {ble_label:<{W-2}}{C_BOLD}{C_CYAN}║{C_RESET}\n"
        out += f"{C_BOLD}{C_CYAN}╠{'═'*W}╣{C_RESET}\n"

        ard_parts = []
        for ax in ['j1', 'j2', 'j3']:
            a = arduino[ax]
            dot = C_GREEN + '●' + C_RESET if a['connected'] else C_RED + '○' + C_RESET
            label = {'j1':'J1','j2':'J2','j3':'J3'}[ax]
            port_str = a['port'] if a['connected'] else '미연결'
            ard_parts.append(f"[{label}]{dot}{port_str:<12}")
        out += f"{C_BOLD}{C_CYAN}║{C_RESET}  아두이노:  {'  '.join(ard_parts)}\n"
        out += f"{C_BOLD}{C_CYAN}╠{'═'*W}╣{C_RESET}\n"

        axis_labels = {'j1':'J1 (1축·상완)', 'j2':'J2 (2축·전완)', 'j3':'J3 (3축·손목)'}
        for axis in ['j1', 'j2', 'j3']:
            s = state[axis]
            out += f"{C_BOLD}{C_CYAN}║{C_RESET} {C_BOLD}{axis_labels[axis]:<14}{C_RESET}  "
            out += f"PWM {C_YELLOW}{s['pwm']:>3}{C_RESET}  {dir_str(s['dir'], s['pwm'])}\n"
            b = bar(s['pwm'])
            if s['enc_connected']:
                enc_info  = f"ENC raw={s['enc_raw']:>4}  {s['enc_deg']:>7.2f}°"
                enc_color = C_DIM
            else:
                enc_info  = "ENC ⚠ 엔코더 미연결"
                enc_color = C_RED
            out += f"{C_BOLD}{C_CYAN}║{C_RESET}   {b}  {enc_color}{enc_info}{C_RESET}\n"
            out += f"{C_BOLD}{C_CYAN}║{C_RESET}\n"

        out += f"{C_BOLD}{C_CYAN}╠{'═'*W}╣{C_RESET}\n"
        out += f"{C_BOLD}{C_CYAN}║{C_RESET}  마지막 명령:  "
        out += f"{C_PURPLE}{last_axis:<3}{C_RESET}  {C_CYAN}{last_dir:<5}{C_RESET}  PWM {C_YELLOW}{last_pwm:<3}{C_RESET}\n"
        out += f"{C_BOLD}{C_CYAN}╚{'═'*W}╝{C_RESET}\n"
        out += f"{C_DIM}  [q + Enter 로 종료]{C_RESET}   \n"

        sys.stdout.write(out)
        sys.stdout.flush()


# ══════════════════════════════════════════════════════════
# 아두이노 시리얼 매니저
# ══════════════════════════════════════════════════════════
class ArduinoSerialManager:
    BAUD = 9600

    def __init__(self, ports=None, dashboard=None):
        self._ports    = ports or {}
        self._serials  = {}
        self._connected = {}
        self._dashboard = dashboard

    def connect_all(self):
        usb_ports = []
        acm_ports = []
        if not self._ports:
            for p in serial.tools.list_ports.comports():
                if 'ttyUSB' in p.device:
                    usb_ports.append(p.device)
                elif 'ttyACM' in p.device:
                    acm_ports.append(p.device)
            usb_ports.sort()
            acm_ports.sort()
            log.info(f"탐색된 나노(ttyUSB): {usb_ports}  우노(ttyACM): {acm_ports}")

        auto_map = {}
        if len(usb_ports) > 0: auto_map['j1'] = usb_ports[0]
        if len(usb_ports) > 1: auto_map['j2'] = usb_ports[1]
        if len(acm_ports) > 0: auto_map['j3']  = acm_ports[0]

        for axis in ['j1', 'j2', 'j3']:
            port = self._ports.get(axis) or auto_map.get(axis)
            if port is None:
                log.warning(f"[{axis.upper()}] 아두이노 포트 없음 — 미연결")
                self._connected[axis] = False
                if self._dashboard:
                    self._dashboard.set_arduino(axis, False)
                continue
            try:
                ser = serial.Serial(port, self.BAUD, timeout=0.1)
                self._serials[axis]   = ser
                self._connected[axis] = True
                log.info(f"[{axis.upper()}] 아두이노 연결: {port} @ {self.BAUD}bps")
                if self._dashboard:
                    self._dashboard.set_arduino(axis, True, port)
            except Exception as e:
                log.warning(f"[{axis.upper()}] 포트 {port} 연결 실패: {e}")
                self._connected[axis] = False
                if self._dashboard:
                    self._dashboard.set_arduino(axis, False)

    def send(self, axis, direction, pwm):
        if not self._connected.get(axis):
            return
        ser = self._serials.get(axis)
        if ser is None:
            return
        cmd = 'S,0\n' if pwm == 0 else (f'F,{pwm&0xFF}\n' if direction == 1 else f'B,{pwm&0xFF}\n')
        try:
            ser.write(cmd.encode())
        except Exception as e:
            log.error(f"[{axis.upper()}] 시리얼 전송 실패: {e}")
            self._connected[axis] = False
            if self._dashboard:
                self._dashboard.set_arduino(axis, False)

    def is_connected(self, axis):
        return self._connected.get(axis, False)

    def close(self):
        for ax, ser in self._serials.items():
            try:
                ser.write(b'S,0\n')
                ser.close()
            except Exception:
                pass
        self._serials.clear()
        self._connected.clear()


# ══════════════════════════════════════════════════════════
# 엔코더 폴러
# ══════════════════════════════════════════════════════════
class EncoderPoller:
    POLL_HZ = 10

    def __init__(self, enc_mgr, dashboard):
        self._enc_mgr = enc_mgr
        self._dash    = dashboard
        self._running = False

    def start(self):
        self._running = True
        if getattr(self, '_thread', None) and self._thread.is_alive(): return
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False
        thread = getattr(self, '_thread', None)
        if thread and thread is not threading.current_thread(): thread.join(timeout=0.5)

    def _loop(self):
        while self._running:
            for axis in ['j1', 'j2', 'j3']:
                try:
                    raw = self._enc_mgr.read_raw(axis)
                    if raw is None:
                        self._dash.update_encoder(axis, 0, 0.0, connected=False)
                    else:
                        self._dash.update_encoder(axis, raw, raw * 360.0 / 4096.0, connected=True)
                except Exception:
                    self._dash.update_encoder(axis, 0, 0.0, connected=False)
            time.sleep(1.0 / self.POLL_HZ)


# ══════════════════════════════════════════════════════════
# BLE 서버 (bless 기반)
# ══════════════════════════════════════════════════════════
class ScaraBLEServer:
    def __init__(self, motor_mgr=None, enc_mgr=None, arduino_ports=None):
        self.motor_mgr   = motor_mgr
        self.enc_mgr     = enc_mgr
        self._rx_buf     = bytearray()
        self._server     = None
        self._loop       = None
        self._shutdown_event = None
        self._dash       = TerminalDashboard()
        self._arduino_mgr = ArduinoSerialManager(ports=arduino_ports, dashboard=self._dash)
        self._arduino_mgr.connect_all()
        self._enc_poller = EncoderPoller(enc_mgr, self._dash) if enc_mgr else None

    def run(self):
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        self._dash.start()
        if self._enc_poller:
            self._enc_poller.start()
        try:
            self._loop.run_until_complete(self._run_ble())
        except KeyboardInterrupt:
            pass
        finally:
            self.stop()
            tasks = asyncio.all_tasks(self._loop)
            for task in tasks: task.cancel()
            if tasks: self._loop.run_until_complete(asyncio.gather(*tasks, return_exceptions=True))
            self._loop.close()
            self._loop = None
            asyncio.set_event_loop(None)

    def stop(self):
        if self._enc_poller:
            self._enc_poller.stop()
        self._dash.stop()
        self._arduino_mgr.close()
        if self.motor_mgr:
            self.motor_mgr.stop_all()
        if self._loop and not self._loop.is_closed() and self._shutdown_event:
            self._loop.call_soon_threadsafe(self._shutdown_event.set)

    async def _run_ble(self):
        self._shutdown_event = asyncio.Event()

        self._server = BlessServer(name='SCARA-ROBOT', loop=self._loop)
        self._server.read_request_func  = self._on_read
        self._server.write_request_func = self._on_write

        await self._server.add_new_service(NUS_SERVICE_UUID)

        # TX (notify)
        tx_flags = (
            GATTCharacteristicProperties.notify
        )
        tx_perms = GATTAttributePermissions.readable
        await self._server.add_new_characteristic(
            NUS_SERVICE_UUID, NUS_TX_UUID, tx_flags, None, tx_perms
        )

        # RX (write)
        rx_flags = (
            GATTCharacteristicProperties.write |
            GATTCharacteristicProperties.write_without_response
        )
        rx_perms = GATTAttributePermissions.writeable
        await self._server.add_new_characteristic(
            NUS_SERVICE_UUID, NUS_RX_UUID, rx_flags, None, rx_perms
        )

        await self._server.start()
        log.info("BLE 광고 시작: 'SCARA-ROBOT' ✓")

        # 무한 대기 (광고 계속 유지)
        try:
            await self._shutdown_event.wait()
        finally:
            await self._server.stop()

    # ── bless 콜백 ───────────────────────────────────────
    def _on_read(self, characteristic: BlessGATTCharacteristic, **kwargs):
        return characteristic.value

    def _on_write(self, characteristic: BlessGATTCharacteristic, value: bytearray, **kwargs):
        if characteristic.uuid.lower() == NUS_RX_UUID.lower():
            self._dash.set_ble(True)
            self._rx_buf.extend(value[:1024])
            if len(self._rx_buf)>2048: self._rx_buf.clear()
            self._parse_buffer()

    def _notify(self, data: bytes):
        if self._server is None:
            return
        try:
            char = self._server.get_characteristic(NUS_TX_UUID)
            if char:
                char.value = bytearray(data)
                self._server.update_value(NUS_SERVICE_UUID, NUS_TX_UUID)
        except Exception as e:
            log.debug(f"notify 실패: {e}")

    # ── 패킷 파싱 ────────────────────────────────────────
    def _parse_buffer(self):
        buf = self._rx_buf
        while len(buf) >= 3:
            if buf[0] not in (PKT_MOTOR_CMD, PKT_ENC_REQ):
                buf.pop(0)
                continue
            if buf[0] == PKT_MOTOR_CMD:
                if len(buf) < 5: break
                if buf[4] == PKT_TAIL:
                    self._handle_motor(buf[1], buf[2], buf[3])
                del buf[:5]
            elif buf[0] == PKT_ENC_REQ:
                if len(buf) < 3: break
                if buf[2] == PKT_TAIL:
                    self._handle_encoder(buf[1])
                del buf[:3]
        self._rx_buf = buf

    def _handle_motor(self, axis_code, direction, pwm):
        axis = AXIS_MAP.get(axis_code)
        if not axis:
            return
        if self._arduino_mgr.is_connected(axis):
            self._arduino_mgr.send(axis, direction, pwm)
        elif self.motor_mgr:
            if pwm == 0:       self.motor_mgr.stop(axis)
            elif direction == 1: self.motor_mgr.forward(axis, pwm)
            else:                self.motor_mgr.backward(axis, pwm)
        self._dash.update_motor(axis, direction, pwm)

    def _handle_encoder(self, axis_code):
        axis = AXIS_MAP.get(axis_code)
        if not axis or not self.enc_mgr:
            return
        try:
            raw = self.enc_mgr.read_raw(axis)
        except Exception:
            raw = None
        if raw is None:
            self._dash.update_encoder(axis, 0, 0.0, connected=False)
            return
        deg = raw * 360.0 / 4096.0
        self._dash.update_encoder(axis, raw, deg, connected=True)
        pkt = bytes([PKT_ENC_RSP, axis_code, (raw >> 8) & 0x0F, raw & 0xFF, PKT_TAIL])
        self._notify(pkt)
