#!/usr/bin/env python3
"""
════════════════════════════════════════════════════════════
encoder_as5600.py  —  AS5600 엔코더 모듈 (라즈베리파이 I2C)

연결:
    라즈베리파이4 GPIO2(SDA), GPIO3(SCL) → TCA9548A → AS5600 × 3

설치:
    sudo pip3 install smbus2

TCA9548A 채널:
    채널 0 → J1 엔코더
    채널 1 → J2 엔코더
    채널 2 → Z  엔코더
════════════════════════════════════════════════════════════
"""

import logging
import threading
from typing import Optional, Dict

log = logging.getLogger('ENCODER')

# ── AS5600 레지스터 ───────────────────────────────────────
AS5600_ADDR    = 0x36
REG_STATUS     = 0x0B
REG_ANGLE_H    = 0x0E
REG_ANGLE_L    = 0x0F

# STATUS 비트
MD = (1 << 5)   # Magnet Detected
ML = (1 << 4)   # Too Low
MH = (1 << 3)   # Too High

# ── TCA9548A 멀티플렉서 ───────────────────────────────────
TCA9548A_ADDR = 0x70


class AS5600:
    """단일 AS5600 엔코더 (TCA9548A 채널 지정)"""

    def __init__(self, bus, mux_channel: int):
        self._bus     = bus
        self._mux_ch  = mux_channel
        self._last_raw = None

    def _select_channel(self):
        """TCA9548A 채널 선택"""
        try:
            self._bus.write_byte(TCA9548A_ADDR, 1 << self._mux_ch)
            return True
        except Exception as e:
            log.error(f"MUX 채널 선택 실패 (ch={self._mux_ch}): {e}")
            return False

    def begin(self) -> bool:
        """초기화 — 마그넷 감지 여부 반환"""
        if not self._select_channel(): return False
        try:
            status = self._bus.read_byte_data(AS5600_ADDR, REG_STATUS)
            detected = bool(status & MD)
            if not detected:
                log.warning(f"MUX ch{self._mux_ch}: 마그넷 감지 안 됨")
            return detected
        except Exception as e:
            log.error(f"MUX ch{self._mux_ch} 초기화 오류: {e}")
            return False

    def read_raw(self) -> Optional[int]:
        """
        12비트 raw 각도값 읽기 (0~4095)
        실패 시 None 반환
        """
        if not self._select_channel(): return None
        try:
            # ANGLE_H(0x0E), ANGLE_L(0x0F) 연속 읽기
            data = self._bus.read_i2c_block_data(AS5600_ADDR, REG_ANGLE_H, 2)
            raw  = ((data[0] & 0x0F) << 8) | data[1]
            self._last_raw = raw
            return raw
        except Exception as e:
            log.warning(f"MUX ch{self._mux_ch} 읽기 오류: {e} — 측정 무효")
            return None

    def read_deg(self) -> float:
        """각도(°) 반환 (0.0 ~ 359.91)"""
        raw = self.read_raw()
        return raw * 360.0 / 4096.0 if raw is not None else 0.0

    def magnet_status(self) -> int:
        """마그넷 상태: 3=최적, 2=너무강함, 1=너무약함, 0=없음"""
        if not self._select_channel(): return 0
        try:
            s = self._bus.read_byte_data(AS5600_ADDR, REG_STATUS)
            if not (s & MD): return 0
            if s & MH:       return 2
            if s & ML:       return 1
            return 3
        except:
            return 0


class EncoderManager:
    """J1, J2, J3 세 개의 AS5600 엔코더를 관리"""

    def __init__(self, i2c_bus_num: int, mux_channels: Dict[str, int]):
        """
        :param i2c_bus_num: I2C 버스 번호 (라즈베리파이4 = 1)
        :param mux_channels: {'j1': 0, 'j2': 1, 'z': 2}
        """
        self._lock = threading.RLock()
        self._bus_num     = i2c_bus_num
        self._mux_channels = mux_channels
        self._bus         = None
        self._encoders: Dict[str, AS5600] = {}

    def init(self) -> bool:
        """I2C 버스 열고 엔코더 초기화"""
        self.close()
        try:
            import smbus2
            self._bus = smbus2.SMBus(self._bus_num)
        except ImportError:
            log.error("smbus2 없음. 설치: sudo pip3 install smbus2")
            return False
        except Exception as e:
            log.error(f"I2C 버스 {self._bus_num} 열기 실패: {e}")
            return False

        all_ok = True
        for axis, ch in self._mux_channels.items():
            enc = AS5600(self._bus, ch)
            ok  = enc.begin()
            self._encoders[axis] = enc
            log.info(f"AS5600 {axis.upper()} (MUX ch{ch}): {'OK ✓' if ok else '마그넷 없음 ✗'}")
            if not ok:
                all_ok = False

        return all_ok

    def read_raw(self, axis: str) -> Optional[int]:
        """축 이름으로 raw값 읽기"""
        enc = self._encoders.get(axis)
        if enc is None:
            log.warning(f"엔코더 '{axis}' 없음")
            return None
        with self._lock:
            return enc.read_raw()

    def read_deg(self, axis: str) -> float:
        """축 이름으로 각도(°) 읽기"""
        enc = self._encoders.get(axis)
        with self._lock:
            return enc.read_deg() if enc else 0.0

    def magnet_status(self, axis: str) -> int:
        enc = self._encoders.get(axis)
        with self._lock:
            return enc.magnet_status() if enc else 0

    def close(self):
        with self._lock:
            if self._bus:
                self._bus.close()
                self._bus = None
            self._encoders.clear()
