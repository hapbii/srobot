import sys
import unittest
from pathlib import Path
from unittest.mock import Mock,patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from encoder_as5600 import AS5600
from motor_gpio import MotorGPIO,MotorManager
from serial_transport import ArduinoSerialManager

class ResourceTests(unittest.TestCase):
    def test_mux_selection_failure_never_reads_previous_channel(self):
        bus=Mock();bus.write_byte.side_effect=OSError('disconnected')
        enc=AS5600(bus,1)
        self.assertIsNone(enc.read_raw());bus.read_i2c_block_data.assert_not_called()
    def test_encoder_failure_does_not_return_last_value(self):
        bus=Mock();bus.read_i2c_block_data.return_value=[1,2]
        enc=AS5600(bus,1);self.assertEqual(enc.read_raw(),258)
        bus.read_i2c_block_data.side_effect=OSError('disconnected')
        self.assertIsNone(enc.read_raw())
    def test_partial_gpio_init_cleans_up_every_opened_pin(self):
        first=Mock();gpio=Mock();gpio.OutputDevice.side_effect=[first,OSError('pin busy')]
        with patch.dict(sys.modules,{'gpiozero':gpio}):
            motor=MotorGPIO(1,2,3,'j1')
            with self.assertRaises(OSError):motor.init()
        first.close.assert_called_once();self.assertIsNone(motor._out_in1)
        motor.cleanup();first.close.assert_called_once()
    def test_gpio_manager_cleanup_releases_references(self):
        manager=MotorManager({});motor=Mock();manager._motors['j1']=motor
        manager.cleanup();self.assertFalse(manager._motors);motor.cleanup.assert_called_once()
    def test_serial_short_write_is_a_failure_and_closes_port(self):
        transport=ArduinoSerialManager();ser=Mock();ser.is_open=True;ser.write.return_value=1
        transport._serials['j1']=ser
        self.assertFalse(transport.send_goto('j1',100,1));ser.close.assert_called_once()
    def test_close_is_idempotent_and_joins_readers(self):
        transport=ArduinoSerialManager();ser=Mock();thread=Mock()
        ser.write.side_effect=lambda payload:len(payload)
        transport._serials['j1']=ser;transport._threads['j1']=thread
        transport.close();transport.close()
        self.assertFalse(transport._serials);self.assertFalse(transport._threads)
        ser.close.assert_called_once();thread.join.assert_called_once()

if __name__=='__main__':unittest.main()
