"""Compatibility entry point for the refactored V2 server."""
from control_server import ScaraWSServer, ScaraBLEServer, deg_to_steps, initial_motor_steps
