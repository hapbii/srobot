#!/usr/bin/env python3
"""
════════════════════════════════════════════════════════════
motor_gpio.py  —  모터 드라이버 GPIO 제어 모듈
                  (gpiozero 기반 — Debian 13 trixie 호환)

연결 (L298N 기준):
    J1: IN1=GPIO17, IN2=GPIO18, ENA=GPIO12(PWM)
    J2: IN1=GPIO22, IN2=GPIO23, ENA=GPIO13(PWM)
    J3: IN1=GPIO24, IN2=GPIO25, ENA=GPIO19(PWM)
════════════════════════════════════════════════════════════
"""

import logging
from typing import Dict

log = logging.getLogger('MOTOR_GPIO')

PWM_FREQ = 1000
PWM_MIN  = 30
PWM_MAX  = 100


class MotorGPIO:
    def __init__(self, in1: int, in2: int, pwm_pin: int, axis: str):
        self._in1     = in1
        self._in2     = in2
        self._pwm_pin = pwm_pin
        self._axis    = axis
        self._out_in1 = None
        self._out_in2 = None
        self._pwm     = None
        self._duty    = 0.0

    def init(self):
        from gpiozero import OutputDevice, PWMOutputDevice
        self._out_in1 = OutputDevice(self._in1,  initial_value=False)
        self._out_in2 = OutputDevice(self._in2,  initial_value=False)
        self._pwm     = PWMOutputDevice(self._pwm_pin, frequency=PWM_FREQ, initial_value=0)
        log.info(f"모터 {self._axis.upper()} 초기화: IN1={self._in1} IN2={self._in2} PWM={self._pwm_pin}")

    def _pwm_byte_to_duty(self, pwm_byte: int) -> float:
        duty = pwm_byte / 255.0
        min_duty = PWM_MIN / 100.0
        if 0 < duty < min_duty:
            duty = min_duty
        return duty

    def _set_duty(self, duty: float):
        duty = max(0.0, min(1.0, duty))
        if duty != self._duty:
            self._pwm.value = duty
            self._duty = duty

    def forward(self, pwm_byte: int):
        duty = self._pwm_byte_to_duty(pwm_byte)
        self._out_in1.on()
        self._out_in2.off()
        self._set_duty(duty)

    def backward(self, pwm_byte: int):
        duty = self._pwm_byte_to_duty(pwm_byte)
        self._out_in1.off()
        self._out_in2.on()
        self._set_duty(duty)

    def stop(self):
        self._out_in1.off()
        self._out_in2.off()
        self._set_duty(0)

    def brake(self):
        self._out_in1.on()
        self._out_in2.on()
        self._set_duty(1.0)

    def cleanup(self):
        try:
            self.stop()
            if self._pwm:     self._pwm.close()
            if self._out_in1: self._out_in1.close()
            if self._out_in2: self._out_in2.close()
        except Exception as e:
            log.warning(f"cleanup 오류: {e}")


class MotorManager:
    def __init__(self, pin_config: Dict):
        self._pin_config = pin_config
        self._motors: Dict[str, MotorGPIO] = {}

    def init(self):
        for axis, pins in self._pin_config.items():
            motor = MotorGPIO(pins['in1'], pins['in2'], pins['pwm'], axis)
            motor.init()
            self._motors[axis] = motor
        log.info("모든 모터 초기화 완료 (gpiozero)")

    def forward(self, axis: str, pwm: int):
        m = self._motors.get(axis)
        if m: m.forward(pwm)

    def backward(self, axis: str, pwm: int):
        m = self._motors.get(axis)
        if m: m.backward(pwm)

    def stop(self, axis: str):
        m = self._motors.get(axis)
        if m: m.stop()

    def stop_all(self):
        for m in self._motors.values():
            m.stop()
        log.info("전체 모터 정지")

    def brake_all(self):
        for m in self._motors.values():
            m.brake()

    def cleanup(self):
        for m in self._motors.values():
            m.cleanup()
        log.info("GPIO 정리 완료")
