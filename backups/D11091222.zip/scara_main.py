#!/usr/bin/env python3
"""
════════════════════════════════════════════════════════════
scara_main.py  —  SCARA 로봇 메인 (WebSocket + 3축 아두이노 나노)

실행:
  sudo python3 scara_main.py
  sudo python3 scara_main.py --j1 /dev/ttyUSB0 --j2 /dev/ttyUSB1 --j3 /dev/ttyUSB2

포트 자동 감지: 각 보드의 J1/J2/J3 READY 신호로 축을 식별

엔코더: 각 아두이노 나노의 A4(SDA)/A5(SCL)에 AS5600 연결
        아두이노가 100ms마다 "ENC,raw\n" 형식으로 라즈베리파이에 전송
════════════════════════════════════════════════════════════
"""

import threading
import signal
import logging
import argparse
import socket

from ws_server  import ScaraWSServer
from motor_gpio import MotorManager

logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] %(levelname)s %(name)s: %(message)s',
    datefmt='%H:%M:%S'
)
log = logging.getLogger('SCARA_MAIN')

MOTOR_PINS = {
    'j1': {'in1': 17, 'in2': 18, 'pwm': 12},
    'j2': {'in1': 22, 'in2': 23, 'pwm': 13},
    'j3': {'in1': 24, 'in2': 25, 'pwm': 19},
}


def main():
    parser = argparse.ArgumentParser(description='SCARA WebSocket 컨트롤러')
    parser.add_argument('--j1', type=str, default=None, help='J1 나노 포트 (기본: ttyUSB0 자동감지)')
    parser.add_argument('--j2', type=str, default=None, help='J2 나노 포트 (기본: ttyUSB1 자동감지)')
    parser.add_argument('--j3', type=str, default=None, help='J3 나노 포트 (기본: ttyUSB2 자동감지)')
    args = parser.parse_args()

    arduino_ports = {}
    if args.j1: arduino_ports['j1'] = args.j1
    if args.j2: arduino_ports['j2'] = args.j2
    if args.j3: arduino_ports['j3'] = args.j3

    log.info("SCARA WebSocket 컨트롤러 시작 (아두이노 나노 × 3)")

    # GPIO 모터 (아두이노 없을 때 폴백용)
    motor_mgr = MotorManager(MOTOR_PINS)
    try:
        motor_mgr.init()
    except Exception as e:
        log.warning(f"GPIO 모터 초기화 실패 (아두이노 사용 시 무시): {e}")

    # WebSocket 서버
    # enc_mgr=None → 엔코더는 각 아두이노 나노가 직접 읽어서 시리얼로 전송
    server = ScaraWSServer(
        motor_mgr=motor_mgr,
        enc_mgr=None,
        arduino_ports=arduino_ports if arduino_ports else None,
    )

    shutdown_requested = threading.Event()

    def shutdown(sig=None, frame=None):
        if shutdown_requested.is_set():
            return
        shutdown_requested.set()
        log.info("종료 중...")
        server.stop()

    signal.signal(signal.SIGINT,  shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    # q 입력 시 종료
    def wait_for_quit():
        while True:
            try:
                if input().strip().lower() == 'q':
                    log.info("'q' 입력 — 종료합니다")
                    shutdown()
            except EOFError:
                break

    threading.Thread(target=wait_for_quit, daemon=True).start()

    # ── 라즈베리파이 IP 표시 ──────────────────────────────
    ips = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ips = [s.getsockname()[0]]
        s.close()
    except Exception:
        pass

    if ips:
        for ip in ips:
            log.info(f"┌─ 접속 주소: ws://{ip}:8765")
            log.info(f"└─ 웹 IP 입력란에 [{ip}] 를 입력하세요")
    else:
        log.info("IP 확인 실패 — 'hostname -I' 로 확인하세요")

    log.info("WebSocket 서버 시작")
    try:
        server.run()
    finally:
        server.stop()
        try:
            motor_mgr.stop_all()
            motor_mgr.cleanup()
        except Exception:
            pass


if __name__ == '__main__':
    main()
