#!/usr/bin/env python3
"""
════════════════════════════════════════════════════════════
ws_server.py  —  WebSocket 서버
                 웹 시뮬레이터 관절값 → 아두이노 스텝모터 실시간 제어

[통신 프로토콜]
  웹 → 라즈베리파이 (JSON):
    {"type":"joint", "j1":45.2, "j2":-30.1, "j3":0.0}  ← 관절 각도(도)
    {"type":"enc_req", "axis":"j1"}
    {"type":"ping"}

  라즈베리파이 → 웹:
    {"type":"enc", "axis":"j1", "raw":2048, "deg":180.0}
    {"type":"pong"}
    {"type":"status", "j1_steps":3200, "j2_steps":-1600, "j3_steps":0}

  라즈베리파이 → 아두이노 (Serial, 각 축 독립):
    "GOTO,3200\n"   ← 목표 스텝 위치 (절대값)
    "SPEED,800\n"   ← 최대 속도 (steps/sec)
    "STOP\n"        ← 즉시 정지

[스텝 변환]
  스텝모터: 200 steps/rev (기본 1.8°/step)
  마이크로스텝: 1600 steps/rev (DM556/MSD-224 기준)
  기어비: J1=20:1, J2=20:1, J3=20:1 (전축 회전형 관절)
  → 전축 공통: 1600 × 20 = 32,000 steps/rev = 88.9 steps/deg
════════════════════════════════════════════════════════════
"""

import asyncio
import json
import logging
import threading
import time
import sys
import socket
import serial
import serial.tools.list_ports
import websockets

log = logging.getLogger('WS_SERVER')

WS_PORT = 8765

# ── 스텝 변환 상수 ────────────────────────────────────────
MICROSTEPS      = 1600          # 드라이버 마이크로스텝 설정 (steps/rev)
GEAR_J1         = 20            # J1 감속비
GEAR_J2         = 20            # J2 감속비
STEPS_PER_DEG_J1 = (MICROSTEPS * GEAR_J1) / 360.0   # 222.2 steps/deg
STEPS_PER_DEG_J2 = (MICROSTEPS * GEAR_J2) / 360.0   # 222.2 steps/deg
GEAR_J3          = 20            # J3 감속비
STEPS_PER_DEG_J3 = (MICROSTEPS * GEAR_J3) / 360.0   # 222.2 steps/deg
# J2 mechanical coupling compensation.
# If J1 motion drags the real J2 axis, command the J2 motor with a counter-rotation.
# Use -1 for J2_motor = J2_web - J1_web. If the real robot gets worse, change to +1.
J2_COMPENSATE_J1 = False
J2_COMP_SIGN     = -1

# Web pose that matches the robot's physical power-on pose.
# The real Arduino stepper position is 0 at boot, while the web starts with J2=180.
JOINT_HOME_DEG = {'j1': 0.0, 'j2': 180.0, 'j3': 0.0}

def initial_motor_steps():
    return {
        'j1': 0,
        'j2': 0,
        'j3':  0,
    }


# 최대 속도/가속도
MAX_SPEED_J1  = 2000   # steps/sec
MAX_SPEED_J2  = 2000
MAX_SPEED_J3  = 1000
ACCEL_J1      = 3000   # steps/sec²
ACCEL_J2      = 3000
ACCEL_J3      = 1500
MIN_LIVE_SPEED = 120
MAX_LIVE_SPEED = 3000
HOME_SEARCH_SPEED = 700
HOME_SEARCH_DIR = {'j1': -1, 'j2': -1, 'j3': -1}
ENCODER_COUNTS_PER_REV = 4096
ENCODER_WRAP_THRESHOLD = ENCODER_COUNTS_PER_REV // 2
ENCODER_DISPLAY_RATIO = {'j1': GEAR_J1, 'j2': GEAR_J2, 'j3': GEAR_J3}

# ── 터미널 컬러 ──────────────────────────────────────────
C_RESET  = '\033[0m'
C_CYAN   = '\033[96m'
C_GREEN  = '\033[92m'
C_YELLOW = '\033[93m'
C_RED    = '\033[91m'
C_PURPLE = '\033[95m'
C_BOLD   = '\033[1m'
C_DIM    = '\033[2m'


# ══════════════════════════════════════════════════════════
# 터미널 대시보드
# ══════════════════════════════════════════════════════════
class TerminalDashboard:
    def __init__(self, local_ip='?.?.?.?'):
        self._local_ip = local_ip
        self._joint = {
            'j1': {'deg': 0.0, 'steps': 0, 'enc_raw': 0, 'enc_deg': 0.0, 'enc_ok': False},
            'j2': {'deg': 0.0, 'steps': 0, 'enc_raw': 0, 'enc_deg': 0.0, 'enc_ok': False},
            'j3' : {'deg': 0.0, 'steps': 0, 'enc_raw': 0, 'enc_deg': 0.0, 'enc_ok': False},
        }
        self._arduino = {
            'j1': {'connected': False, 'port': '—'},
            'j2': {'connected': False, 'port': '—'},
            'j3' : {'connected': False, 'port': '—'},
        }
        self._ws_connected  = False
        self._ws_clients    = 0
        self._controlling   = False   # 웹에서 "제어 시작" 눌린 상태
        self._lock          = threading.Lock()
        self._running       = False
        self._pkt_count     = 0
        self._thread        = None

    def set_controlling(self, active: bool):
        with self._lock:
            self._controlling = active

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._running = True
        sys.stdout.write('\033[?25l')
        sys.stdout.flush()
        self._thread = threading.Thread(target=self._loop, daemon=True, name='scara-dashboard')
        self._thread.start()

    def stop(self):
        self._running = False
        if self._thread and self._thread is not threading.current_thread():
            self._thread.join(timeout=0.5)
        self._thread = None
        sys.stdout.write('\033[?25h\n')
        sys.stdout.flush()

    def update_joint(self, axis, deg, steps):
        with self._lock:
            if axis in self._joint:
                self._joint[axis]['deg']   = deg
                self._joint[axis]['steps'] = steps
                self._pkt_count += 1

    def update_encoder(self, axis, raw, deg, ok=True):
        with self._lock:
            if axis in self._joint:
                self._joint[axis]['enc_raw'] = raw
                self._joint[axis]['enc_deg'] = deg
                self._joint[axis]['enc_ok']  = ok

    def set_ws(self, clients):
        with self._lock:
            self._ws_clients   = clients
            self._ws_connected = clients > 0

    def set_arduino(self, axis, connected, port='—'):
        with self._lock:
            if axis in self._arduino:
                self._arduino[axis]['connected'] = connected
                self._arduino[axis]['port']      = port

    def _loop(self):
        print('\033[2J\033[H', end='')
        pkt_buf, last_t = 0, time.time()
        while self._running:
            now = time.time()
            with self._lock:
                pkt_buf += self._pkt_count
                self._pkt_count = 0
            if now - last_t >= 1.0:
                hz = pkt_buf / (now - last_t)
                pkt_buf, last_t = 0, now
            else:
                hz = pkt_buf
            self._render(hz)
            time.sleep(0.05)

    def _render(self, hz=0):
        with self._lock:
            joint        = {k: dict(v) for k, v in self._joint.items()}
            arduino      = {k: dict(v) for k, v in self._arduino.items()}
            ws_ok        = self._ws_connected
            ws_n         = self._ws_clients
            lip          = self._local_ip
            controlling  = self._controlling

        out = '\033[H'
        W   = 66

        out += f"{C_BOLD}{C_CYAN}╔{'═'*W}╗{C_RESET}\n"
        out += f"{C_BOLD}{C_CYAN}║{C_RESET}{'  SCARA ROBOT  ─  실시간 관절 제어 모니터':^{W}}{C_BOLD}{C_CYAN}║{C_RESET}\n"
        out += f"{C_BOLD}{C_CYAN}╠{'═'*W}╣{C_RESET}\n"

        # WebSocket 상태
        ws_dot = C_GREEN+'●'+C_RESET if ws_ok else C_RED+'○'+C_RESET
        if ws_ok:
            ctrl_badge = (C_GREEN+C_BOLD+' ▶ 제어 중 '+C_RESET) if controlling else (C_DIM+' ■ 대기 중 '+C_RESET)
            ws_label = (f"ws://{lip}:{WS_PORT}  클라이언트 {ws_n}개  "
                        f"{C_YELLOW}{hz:.0f}{C_RESET} pkt/s  {ctrl_badge}")
        else:
            ws_label = f"ws://{lip}:{WS_PORT}  {C_RED}연결 대기중{C_RESET}"
        out += f"{C_BOLD}{C_CYAN}║{C_RESET}  WebSocket {ws_dot} {ws_label}\n"
        out += f"{C_BOLD}{C_CYAN}╠{'═'*W}╣{C_RESET}\n"

        # 아두이노 연결 상태
        ard_line = '  아두이노:  '
        for ax in ['j1', 'j2', 'j3']:
            a   = arduino[ax]
            dot = C_GREEN+'●'+C_RESET if a['connected'] else C_RED+'○'+C_RESET
            lbl = {'j1':'J1','j2':'J2','j3':'J3'}[ax]
            prt = a['port'] if a['connected'] else C_RED+'미연결   '+C_RESET
            ard_line += f"[{lbl}]{dot}{prt:<12}"
        out += f"{C_BOLD}{C_CYAN}║{C_RESET}{ard_line}\n"
        out += f"{C_BOLD}{C_CYAN}╠{'═'*W}╣{C_RESET}\n"

        # 열 헤더
        out += f"{C_BOLD}{C_CYAN}║{C_RESET}  {'축':<16}  {'웹 수신값':>10}  {'→ GOTO 스텝':>12}  {'엔코더':>14}\n"
        out += f"{C_BOLD}{C_CYAN}╠{'═'*W}╣{C_RESET}\n"

        # 축별 상태
        labels  = {'j1':'J1  상완', 'j2':'J2  전완', 'j3':'J3  손목'}
        units   = {'j1':'°',        'j2':'°',        'j3':'°'}
        max_rng = {'j1': 360.0,     'j2': 360.0,     'j3': 360.0}

        for axis in ['j1', 'j2', 'j3']:
            j    = joint[axis]
            unit = units[axis]
            maxv = max_rng[axis]

            # 진행 바 (16칸)
            norm   = max(0.0, min(1.0, (j['deg'] + maxv) / (maxv * 2)))
            filled = int(norm * 16)
            bar    = C_GREEN+'█'*filled + C_DIM+'░'*(16-filled)+C_RESET

            # 웹 수신값 컬러 — 제어 중이면 밝게
            val_clr = C_YELLOW if controlling else C_DIM
            enc_str = (f"{C_DIM}{j['enc_deg']:>7.2f}°{C_RESET}"
                       if j['enc_ok'] else f"{C_RED}미연결{C_RESET}")

            out += f"{C_BOLD}{C_CYAN}║{C_RESET} {C_BOLD}{labels[axis]:<8}{C_RESET}  {bar}"
            out += f"  {val_clr}{j['deg']:>+8.2f}{unit}{C_RESET}"
            out += f"  {C_CYAN}{j['steps']:>+10,d}{C_RESET}"
            out += f"  {enc_str}\n"

        out += f"{C_BOLD}{C_CYAN}╚{'═'*W}╝{C_RESET}\n"
        out += f"{C_DIM}  [q + Enter 로 종료]   {'■ 제어 시작 버튼을 누르면 전송 시작' if not controlling else '▶ 시뮬레이터 값 전송 중'}{C_RESET}   \n"

        sys.stdout.write(out)
        sys.stdout.flush()


# ══════════════════════════════════════════════════════════
# 아두이노 시리얼 매니저
# ══════════════════════════════════════════════════════════
class ArduinoSerialManager:
    BAUD = 115200   # AccelStepper 제어는 빠른 보드레이트 권장

    def __init__(self, ports=None, dashboard=None):
        self._ports            = ports or {}
        self._serials          = {}
        self._connected        = {}
        self._dashboard        = dashboard
        self._lock             = threading.Lock()
        self._ws_broadcast_cb  = None   # ScaraWSServer가 주입
        self._reader_threads   = {}

    def connect_all(self):
        if self._ports:
            axis_ports = dict(self._ports)
        else:
            usb_ports = []
            for p in serial.tools.list_ports.comports():
                if 'ttyUSB' in p.device or 'ttyACM' in p.device:
                    usb_ports.append(p.device)
            usb_ports.sort()
            log.info(f"Arduino candidates: {usb_ports}")
            axis_ports = self._detect_axis_ports(usb_ports)

            # READY 신호로 못 찾은 포트는 한 번 더 재시도 (부팅이 늦었을 수 있음)
            unmatched = [p for p in usb_ports if p not in axis_ports.values()]
            missing_axes = [a for a in ('j1', 'j2', 'j3') if a not in axis_ports]
            if unmatched and missing_axes:
                log.warning(f"READY 미확인 포트 재시도: {unmatched}")
                retry = self._detect_axis_ports(unmatched)
                axis_ports.update(retry)

            # 그래도 못 찾은 축은 ttyUSB 번호 순서로 추측 배정 (틀릴 수 있으니 크게 경고)
            still_unmatched = [p for p in usb_ports if p not in axis_ports.values()]
            for axis in ('j1', 'j2', 'j3'):
                if axis not in axis_ports and still_unmatched:
                    guessed = still_unmatched.pop(0)
                    axis_ports[axis] = guessed
                    log.warning(
                        f"[{axis.upper()}] READY 신호를 못 받아 포트 순서로 추측 배정: {guessed} "
                        f"— 실제 배선/보드와 다를 수 있으니 부팅 로그를 확인하세요!"
                    )

        log.info(f"Arduino axis map: {axis_ports}")

        for axis in ['j1', 'j2', 'j3']:
            port = axis_ports.get(axis)
            if port is None:
                log.warning(f"[{axis.upper()}] serial port missing")
                self._connected[axis] = False
                if self._dashboard: self._dashboard.set_arduino(axis, False)
                continue
            try:
                ser = serial.Serial(port, self.BAUD, timeout=0.05)
                time.sleep(2.0)
                # Keep the READY line available for diagnostics, then clear stale ENC data.
                ready_lines = self._read_startup_lines(ser, wait_s=0.3)
                if ready_lines:
                    log.info(f"[{axis.upper()}] startup: {' | '.join(ready_lines)}")
                ser.reset_input_buffer()
                self._serials[axis]   = ser
                self._connected[axis] = True
                log.info(f"[{axis.upper()}] connected: {port} @ {self.BAUD}bps")
                if self._dashboard: self._dashboard.set_arduino(axis, True, port)
                self._init_axis(axis)
                t = threading.Thread(
                    target=self._serial_reader, args=(axis,), daemon=True,
                    name=f'scara-serial-{axis}'
                )
                self._reader_threads[axis] = t
                t.start()
            except Exception as e:
                log.warning(f"[{axis.upper()}] {port} connect failed: {e}")
                self._connected[axis] = False
                if self._dashboard: self._dashboard.set_arduino(axis, False)

    def _read_startup_lines(self, ser, wait_s=2.5):
        lines = []
        end_t = time.time() + wait_s
        buf = ''
        while time.time() < end_t:
            try:
                c = ser.read(1).decode('ascii', errors='ignore')
            except Exception:
                break
            if not c:
                continue
            if c == '\n':
                line = buf.strip()
                buf = ''
                if line:
                    lines.append(line)
            elif c != '\r':
                buf += c
        if buf.strip():
            lines.append(buf.strip())
        return lines

    def _detect_axis_ports(self, ports):
        ready_to_axis = {
            'J1 READY': 'j1',
            'J2 READY': 'j2',
            'J3 READY': 'j3',
        }
        axis_ports = {}
        for port in ports:
            try:
                ser = serial.Serial(port, self.BAUD, timeout=0.05)
                time.sleep(2.5)
                lines = self._read_startup_lines(ser, wait_s=1.5)
                ser.close()
                log.info(f"[probe {port}] {' | '.join(lines) if lines else 'no READY line'}")
                for line in lines:
                    upper = line.upper()
                    for ready, axis in ready_to_axis.items():
                        if ready in upper:
                            axis_ports[axis] = port
                            break
            except Exception as e:
                log.warning(f"[probe {port}] failed: {e}")
        return axis_ports

    def _init_axis(self, axis):
        """아두이노 초기 파라미터 전송"""
        speed = {'j1': MAX_SPEED_J1, 'j2': MAX_SPEED_J2, 'j3': MAX_SPEED_J3}[axis]
        accel = {'j1': ACCEL_J1,     'j2': ACCEL_J2,     'j3': ACCEL_J3}[axis]
        self._write(axis, f"SPEED,{speed}")
        time.sleep(0.05)
        self._write(axis, f"ACCEL,{accel}")
        time.sleep(0.05)
        self._write(axis, "GOTO,0")   # 현재 위치를 0으로 인식

    def send_speed(self, axis, speed):
        speed = max(MIN_LIVE_SPEED, min(MAX_LIVE_SPEED, int(speed)))
        self._write(axis, f"SPEED,{speed}")

    def send_goto(self, axis, steps):
        """목표 스텝 위치 전송 (절대값)"""
        self._write(axis, f"GOTO,{int(steps)}")

    def send_home_search(self, axis, direction=-1, speed=HOME_SEARCH_SPEED):
        direction = -1 if int(direction) < 0 else 1
        speed = max(MIN_LIVE_SPEED, min(MAX_LIVE_SPEED, int(speed)))
        self._write(axis, f"HOME_SEARCH,{direction},{speed}")

    def send_home_zero(self, axis):
        self._write(axis, "HOME")

    def send_stop(self, axis):
        self._write(axis, "STOP")

    def stop_all(self):
        for axis in ['j1', 'j2', 'j3']:
            self.send_stop(axis)

    def _serial_reader(self, axis):
        """아두이노 시리얼 수신 루프 — ENC,raw 파싱"""
        ser = self._serials.get(axis)
        if ser is None:
            return
        buf = ''
        while self._connected.get(axis):
            try:
                c = ser.read(1).decode('ascii', errors='ignore')
                if not c:
                    continue
                if c == '\n':
                    line = buf.strip()
                    buf  = ''
                    if line.startswith('ENC,'):
                        try:
                            parts = line[4:].split(',')
                            raw   = int(parts[0])
                            sensor = int(parts[1]) if len(parts) >= 2 else None
                            if raw < 0:
                                if self._dashboard:
                                    self._dashboard.update_encoder(axis, 0, 0.0, ok=False)
                                if self._ws_broadcast_cb:
                                    self._ws_broadcast_cb(axis, None, None, sensor)
                                continue
                            deg   = raw * 360.0 / 4096.0
                            if self._dashboard:
                                self._dashboard.update_encoder(axis, raw, deg, ok=True)
                            # WebSocket 브로드캐스트 (이벤트 루프에 예약)
                            if self._ws_broadcast_cb:
                                self._ws_broadcast_cb(axis, raw, deg, sensor)
                        except ValueError:
                            pass
                    elif line.startswith('HOME_DONE'):
                        parts = line.split(',')
                        raw = None
                        sensor = None
                        try:
                            raw = int(parts[1]) if len(parts) > 1 and parts[1] != '' else None
                            sensor = int(parts[2]) if len(parts) > 2 and parts[2] != '' else None
                        except ValueError:
                            pass
                        if self._ws_broadcast_cb:
                            self._ws_broadcast_cb(axis, raw, None, sensor, home_done=True)
                    elif line:
                        log.debug(f"[{axis.upper()}] 아두이노: {line}")
                else:
                    buf += c
            except Exception:
                break
        self._connected[axis] = False
        if self._dashboard:
            self._dashboard.set_arduino(axis, False)

    def _write(self, axis, cmd):
        if not self._connected.get(axis): return
        ser = self._serials.get(axis)
        if ser is None: return
        try:
            with self._lock:
                ser.write((cmd + '\n').encode())
        except Exception as e:
            log.error(f"[{axis.upper()}] 전송 실패: {e}")
            self._connected[axis] = False
            if self._dashboard: self._dashboard.set_arduino(axis, False)

    def is_connected(self, axis):
        return self._connected.get(axis, False)

    def close(self):
        if not self._serials:
            return
        self.stop_all()
        time.sleep(0.1)
        for axis in list(self._connected):
            self._connected[axis] = False
        for axis, ser in list(self._serials.items()):
            try:
                ser.close()
            except Exception:
                pass
            if self._dashboard:
                self._dashboard.set_arduino(axis, False)
        for thread in list(self._reader_threads.values()):
            if thread is not threading.current_thread():
                thread.join(timeout=0.5)
        self._reader_threads.clear()
        self._serials.clear()


# ══════════════════════════════════════════════════════════
# 엔코더 폴러
# ══════════════════════════════════════════════════════════
class EncoderPoller:
    POLL_HZ = 10
    def __init__(self, enc_mgr, dashboard):
        self._enc  = enc_mgr
        self._dash = dashboard
        self._run  = False
        self._thread = None

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._run = True
        self._thread = threading.Thread(target=self._loop, daemon=True, name='scara-encoder-poller')
        self._thread.start()

    def stop(self):
        self._run = False
        if self._thread and self._thread is not threading.current_thread():
            self._thread.join(timeout=0.5)
        self._thread = None

    def _loop(self):
        while self._run:
            for axis in ['j1', 'j2', 'j3']:
                try:
                    raw = self._enc.read_raw(axis)
                    if raw is None: self._dash.update_encoder(axis, 0, 0.0, ok=False)
                    else:           self._dash.update_encoder(axis, raw, raw*360/4096, ok=True)
                except: self._dash.update_encoder(axis, 0, 0.0, ok=False)
            time.sleep(1.0 / self.POLL_HZ)


# ══════════════════════════════════════════════════════════
# 각도 → 스텝 변환
# ══════════════════════════════════════════════════════════
def deg_to_steps(axis, deg):
    home = JOINT_HOME_DEG.get(axis, 0.0)
    rel = deg - home
    if   axis == 'j1': return int(round(rel * STEPS_PER_DEG_J1))
    elif axis == 'j2': return int(round(rel * STEPS_PER_DEG_J2))
    elif axis == 'j3':  return int(round(rel * STEPS_PER_DEG_J3))
    return 0


def joint_targets_to_motor_degrees(targets):
    """Convert web joint targets to physical motor targets.

    Web J2 is the visual/relative forearm angle. On this SCARA build, J1 motion
    mechanically carries the J2 axis, so the J2 motor needs a J1 counter-command
    to keep the real robot matching the web pose.
    """
    j1 = float(targets.get('j1', 0.0))
    j2 = float(targets.get('j2', 0.0))
    j3 = float(targets.get('j3', 0.0))
    if J2_COMPENSATE_J1:
        j2 = j2 + (J2_COMP_SIGN * j1)
    return {'j1': j1, 'j2': j2, 'j3': j3}


# ══════════════════════════════════════════════════════════
# WebSocket 서버
# ══════════════════════════════════════════════════════════
class ScaraWSServer:
    def __init__(self, motor_mgr=None, enc_mgr=None, arduino_ports=None):
        self.motor_mgr     = motor_mgr
        self.enc_mgr       = enc_mgr
        self._clients      = set()
        # asyncio.Lock()은 이벤트 루프 실행 중에 만들어야 함 → lazy init
        self._clients_lock = None
        self._local_ip     = self._get_local_ip()
        self._dash         = TerminalDashboard(local_ip=self._local_ip)
        self._arduino      = ArduinoSerialManager(ports=arduino_ports, dashboard=self._dash)
        self._arduino._ws_broadcast_cb = self._queue_enc_broadcast
        self._enc_queue    = []
        self._arduino.connect_all()
        self._enc_poller   = EncoderPoller(enc_mgr, self._dash) if enc_mgr else None
        self._loop         = None
        self._shutdown_event = None
        self._stopping     = False
        self._last_steps   = initial_motor_steps()
        self._last_joint   = dict(JOINT_HOME_DEG)
        self._last_enc     = {
            'j1': {'raw': None, 'deg': None, 'ok': False},
            'j2': {'raw': None, 'deg': None, 'ok': False},
            'j3':  {'raw': None, 'deg': None, 'ok': False},
        }
        self._home_offset      = {'j1': None, 'j2': None, 'j3': None}
        self._homing            = {'j1': False, 'j2': False, 'j3': False}
        self._current_speed     = {'j1': MAX_SPEED_J1, 'j2': MAX_SPEED_J2, 'j3': MAX_SPEED_J3}
        self._enc_prev_raw      = {'j1': None, 'j2': None, 'j3': None}
        self._enc_unwrapped     = {'j1': 0,    'j2': 0,    'j3': 0}
        self._enc_home_count    = {'j1': 0,    'j2': 0,    'j3': 0}
        self._last_sensor_state = {'j1': 1,   'j2': 1,   'j3': 1}   # 1=비감지, 0=감지

    @staticmethod
    def _get_local_ip():
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(('8.8.8.8', 80))
            ip = s.getsockname()[0]; s.close(); return ip
        except: return '?.?.?.?'

    def _encoder_display_deg(self, axis, raw, reset_home=False):
        """Convert AS5600 raw count to continuous, home-relative output angle.

        AS5600 is absolute 0..4095, so crossing zero looks like 359->0 unless
        the server unwraps it. J1/J2 are also divided by the gearbox ratio so
        the dashboard shows joint-side angle, not motor-side encoder angle.
        """
        if raw is None or axis not in self._enc_unwrapped:
            return None
        prev = self._enc_prev_raw.get(axis)
        if prev is None:
            self._enc_unwrapped[axis] = int(raw)
        else:
            delta = int(raw) - int(prev)
            if delta > ENCODER_WRAP_THRESHOLD:
                delta -= ENCODER_COUNTS_PER_REV
            elif delta < -ENCODER_WRAP_THRESHOLD:
                delta += ENCODER_COUNTS_PER_REV
            self._enc_unwrapped[axis] += delta
        self._enc_prev_raw[axis] = int(raw)
        if reset_home:
            self._enc_home_count[axis] = self._enc_unwrapped[axis]
        rel_count = self._enc_unwrapped[axis] - self._enc_home_count.get(axis, 0)
        motor_deg = rel_count * 360.0 / ENCODER_COUNTS_PER_REV
        ratio = ENCODER_DISPLAY_RATIO.get(axis, 1) or 1
        return round(motor_deg / ratio, 2)

    def _queue_enc_broadcast(self, axis, raw, deg, sensor=None, home_done=False):
        """Receive Arduino feedback and queue it for WS clients."""
        enc_deg = self._encoder_display_deg(axis, raw, reset_home=home_done)
        if deg is not None and enc_deg is None:
            enc_deg = round(deg, 2)
        if raw is not None and enc_deg is not None:
            self._dash.update_encoder(axis, raw, enc_deg, ok=True)
        if axis in self._last_enc and raw is not None:
            self._last_enc[axis] = {'raw': raw, 'deg': enc_deg, 'ok': True}

        if home_done and axis in self._homing:
            self._homing[axis] = False
            self._home_offset[axis] = raw
            self._last_steps[axis] = 0
            self._last_joint[axis] = 0.0
            log.info(f"[{axis.upper()}] HOME_DONE raw={raw}")
            if self._loop:
                self._loop.call_soon_threadsafe(
                    self._enc_queue.append,
                    {'type': 'home_saved', 'axis': axis, 'raw': raw, 'deg': enc_deg, 'done': True}
                )
                if all(not v for v in self._homing.values()) and all(v is not None for v in self._home_offset.values()):
                    self._loop.call_soon_threadsafe(
                        self._enc_queue.append,
                        {'type': 'home_all_set', 'offsets': dict(self._home_offset), 'pose': {'j1': 0, 'j2': 0, 'j3': 0}, 'ts': time.time()}
                    )

        if sensor is not None and axis in self._last_sensor_state:
            prev = self._last_sensor_state[axis]
            self._last_sensor_state[axis] = sensor
            if prev == 1 and sensor == 0 and not home_done:
                if self._loop:
                    self._loop.call_soon_threadsafe(
                        self._enc_queue.append,
                        {'type': 'home_sensor', 'axis': axis, 'raw': raw, 'deg': enc_deg}
                    )

        if self._loop and raw is not None:
            self._loop.call_soon_threadsafe(
                self._enc_queue.append,
                {'type': 'enc', 'axis': axis, 'raw': raw, 'deg': enc_deg, 'ok': True}
            )

    async def _enc_broadcast_loop(self):
        """큐에 쌓인 엔코더 데이터를 모든 웹 클라이언트에 브로드캐스트"""
        while self._shutdown_event and not self._shutdown_event.is_set():
            if self._enc_queue:
                msgs = self._enc_queue[:]
                self._enc_queue.clear()
                for msg in msgs:
                    await self._broadcast(msg)
            await asyncio.sleep(0.05)   # 20Hz

    # ── 외부 인터페이스 ──────────────────────────────────
    def run(self):
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        self._shutdown_event = asyncio.Event()
        self._stopping = False
        self._dash.start()
        if self._enc_poller: self._enc_poller.start()
        try:
            self._loop.run_until_complete(self._run_ws())
        except KeyboardInterrupt:
            pass
        finally:
            self.stop()
            pending = asyncio.all_tasks(self._loop)
            for task in pending:
                task.cancel()
            if pending:
                self._loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
            self._loop.close()
            asyncio.set_event_loop(None)
            self._loop = None
            self._shutdown_event = None
            self._clients_lock = None
            self._clients.clear()

    def stop(self):
        if self._stopping:
            return
        self._stopping = True
        if self._enc_poller: self._enc_poller.stop()
        self._dash.stop()
        self._arduino.close()
        if self._loop and self._shutdown_event:
            self._loop.call_soon_threadsafe(self._shutdown_event.set)

    # ── WebSocket ─────────────────────────────────────────
    async def _run_ws(self):
        log.info(f"WebSocket 서버 시작: ws://0.0.0.0:{WS_PORT}")
        async with websockets.serve(
            self._handler, '0.0.0.0', WS_PORT,
            ping_interval=20, ping_timeout=60,
            max_size=2**16,
        ):
            broadcast_task = asyncio.create_task(
                self._enc_broadcast_loop(), name='encoder-broadcast'
            )
            try:
                await self._shutdown_event.wait()
            finally:
                broadcast_task.cancel()
                await asyncio.gather(broadcast_task, return_exceptions=True)

    async def _handler(self, websocket):
        if self._clients_lock is None:
            self._clients_lock = asyncio.Lock()
        async with self._clients_lock:
            self._clients.add(websocket)
            self._dash.set_ws(len(self._clients))
        log.info(f"클라이언트 연결: {websocket.remote_address}")
        await websocket.send(json.dumps({'type': 'hello', 'server': 'scara-ws', 'port': WS_PORT}))
        await websocket.send(json.dumps(self._status_payload()))
        try:
            async for msg in websocket:
                await self._on_message(websocket, msg)
        except websockets.exceptions.ConnectionClosed:
            pass
        finally:
            if self._clients_lock:
                async with self._clients_lock:
                    self._clients.discard(websocket)
                    self._dash.set_ws(len(self._clients))
            else:
                self._clients.discard(websocket)
                self._dash.set_ws(len(self._clients))
            # 클라이언트가 0명이 되면 제어 상태 초기화
            if len(self._clients) == 0:
                self._dash.set_controlling(False)
                self._last_steps = initial_motor_steps()
                self._last_joint = dict(JOINT_HOME_DEG)
                log.info("■ 클라이언트 해제 — 제어 대기 상태로 전환")
            log.info(f"클라이언트 해제: {websocket.remote_address}")

    def _axis_status(self, axis):
        return {
            'connected': self._arduino.is_connected(axis),
            'target': self._last_joint.get(axis, 0.0),
            'steps': self._last_steps.get(axis),
            'encoder': self._last_enc.get(axis, {'raw': None, 'deg': None, 'ok': False}),
        }

    def _status_payload(self):
        return {
            'type': 'status',
            'axes': {axis: self._axis_status(axis) for axis in ('j1', 'j2', 'j3')},
            'j1_steps': self._last_steps.get('j1'),
            'j2_steps': self._last_steps.get('j2'),
            'j3_steps': self._last_steps.get('j3'),
            'ts': time.time(),
        }

    async def _send_status(self, websocket=None):
        payload = self._status_payload()
        if websocket is None:
            await self._broadcast(payload)
        else:
            await websocket.send(json.dumps(payload))

    async def _on_message(self, websocket, msg):
        try:
            data = json.loads(msg)
        except Exception:
            await websocket.send(json.dumps({'type': 'error', 'message': 'invalid json'}))
            return

        t = data.get('type')

        if t == 'joint':
            if not self._dash._controlling:
                self._dash.set_controlling(True)
                log.info('control started: receiving joint targets')

            try:
                targets = {
                    'j1': float(data.get('j1', self._last_joint['j1'])),
                    'j2': float(data.get('j2', self._last_joint['j2'])),
                    'j3': float(data.get('j3', self._last_joint['j3'])),
                }
            except (TypeError, ValueError):
                await websocket.send(json.dumps({'type': 'error', 'message': 'bad joint value'}))
                return

            speed = self._parse_speed(data.get('speed'))
            motor_targets = joint_targets_to_motor_degrees(targets)

            prev_joint = dict(self._last_joint)
            sent = {}
            for axis in ('j1', 'j2', 'j3'):
                web_value = targets[axis]
                motor_value = motor_targets[axis]
                steps = deg_to_steps(axis, motor_value)
                target_changed = abs(web_value - prev_joint.get(axis, web_value)) > 1e-6

                # With J2 compensation enabled, J1 motion also changes the J2 motor target.
                if axis == 'j2' and J2_COMPENSATE_J1:
                    target_changed = target_changed or abs(targets['j1'] - prev_joint.get('j1', targets['j1'])) > 1e-6

                self._last_joint[axis] = web_value
                if target_changed and steps != self._last_steps[axis]:
                    # 속도 변화가 100 steps/sec 이상으로 클 때만 아두이노에 SPEED 전송하여 시리얼 오버헤드 완화
                    if speed is not None and (self._current_speed.get(axis) is None or abs(speed - self._current_speed[axis]) >= 100):
                        self._arduino.send_speed(axis, speed)
                        self._current_speed[axis] = speed
                    self._last_steps[axis] = steps
                    self._arduino.send_goto(axis, steps)
                    sent[axis] = steps
                    log.info(f"GOTO {axis.upper()}: web={web_value:.2f} motor={motor_value:.2f} steps={steps} speed={self._current_speed.get(axis)}")
                self._dash.update_joint(axis, web_value, steps)

            ack = {
                'type': 'joint_ack',
                'target': targets,
                'motor_target': motor_targets,
                'j2_compensated': J2_COMPENSATE_J1,
                'steps': dict(self._last_steps),
                'speed': speed,
                'sent': sent,
                'arduino': {axis: self._arduino.is_connected(axis) for axis in ('j1', 'j2', 'j3')},
                'ts': time.time(),
            }
            await websocket.send(json.dumps(ack))
            await self._broadcast(self._status_payload())

        elif t == 'stop':
            self._arduino.stop_all()
            self._dash.set_controlling(False)
            await self._broadcast({'type': 'stopped', 'ts': time.time()})

        elif t == 'enc_req':
            axis = data.get('axis', '')
            resp = self._read_encoder(axis)
            if resp:
                await websocket.send(json.dumps(resp))
            else:
                await websocket.send(json.dumps({'type': 'enc', 'axis': axis, 'raw': None, 'deg': None, 'ok': False}))

        elif t == 'status_req':
            await self._send_status(websocket)

        elif t == 'ping':
            await websocket.send(json.dumps({'type': 'pong', 'ts': time.time()}))

        elif t == 'go_home':
            results = {}
            speed = self._parse_speed(data.get('speed')) or HOME_SEARCH_SPEED
            for axis in ['j1', 'j2', 'j3']:
                if self._home_offset.get(axis) is None:
                    results[axis] = {'ok': False, 'reason': 'home not set'}
                    continue
                self._arduino.send_speed(axis, speed)
                self._arduino.send_goto(axis, 0)
                self._current_speed[axis] = speed
                self._last_steps[axis] = 0
                self._last_joint[axis] = 0.0
                self._dash.update_joint(axis, 0.0, 0)
                results[axis] = {'ok': True, 'steps': 0}
                log.info(f"[{axis.upper()}] go home -> steps=0 speed={speed}")
            await self._broadcast({'type': 'going_home', 'results': results, 'pose': {'j1': 0, 'j2': 0, 'j3': 0}, 'ts': time.time()})

        elif t == 'home_start':
            speed = self._parse_speed(data.get('speed')) or HOME_SEARCH_SPEED
            results = {}
            for axis in ['j1', 'j2', 'j3']:
                if not self._arduino.is_connected(axis):
                    results[axis] = {'ok': False, 'reason': 'not connected'}
                    continue
                self._homing[axis] = True
                self._arduino.send_home_search(axis, HOME_SEARCH_DIR.get(axis, -1), speed)
                results[axis] = {'ok': True, 'dir': HOME_SEARCH_DIR.get(axis, -1), 'speed': speed}
                log.info(f"[{axis.upper()}] home search start dir={HOME_SEARCH_DIR.get(axis, -1)} speed={speed}")
            await self._broadcast({'type': 'home_started', 'results': results, 'ts': time.time()})

        elif t == 'home_status':
            # 현재 저장된 홈 오프셋 정보 반환
            payload = {
                'type': 'home_status',
                'offsets': {
                    axis: {'raw': self._home_offset[axis], 'deg': 0.0 if self._home_offset[axis] is not None else None}
                    for axis in ['j1', 'j2', 'j3']
                },
                'ts': time.time(),
            }
            await websocket.send(json.dumps(payload))

        else:
            await websocket.send(json.dumps({'type': 'error', 'message': f'unknown message type: {t}'}))

    def _parse_speed(self, value):
        try:
            speed = int(round(float(value)))
        except (TypeError, ValueError):
            return None
        return max(MIN_LIVE_SPEED, min(MAX_LIVE_SPEED, speed))

    def _read_encoder(self, axis):
        if axis not in ('j1', 'j2', 'j3'):
            return None
        cached = self._last_enc.get(axis)
        if cached and cached.get('ok'):
            return {'type': 'enc', 'axis': axis, 'raw': cached['raw'], 'deg': cached['deg'], 'ok': True}
        if not self.enc_mgr:
            return None
        try:
            raw = self.enc_mgr.read_raw(axis)
        except Exception:
            raw = None
        if raw is None:
            self._dash.update_encoder(axis, 0, 0.0, ok=False)
            self._last_enc[axis] = {'raw': None, 'deg': None, 'ok': False}
            return None
        deg = self._encoder_display_deg(axis, raw)
        self._dash.update_encoder(axis, raw, deg, ok=True)
        self._last_enc[axis] = {'raw': raw, 'deg': deg, 'ok': True}
        return {'type': 'enc', 'axis': axis, 'raw': raw, 'deg': deg, 'ok': True}

    async def _broadcast(self, data):
        if not self._clients: return
        msg = json.dumps(data)
        if self._clients_lock:
            async with self._clients_lock:
                clients = set(self._clients)
        else:
            clients = set(self._clients)
        for ws in clients:
            try: await ws.send(msg)
            except: pass


# 하위 호환
ScaraBLEServer = ScaraWSServer
