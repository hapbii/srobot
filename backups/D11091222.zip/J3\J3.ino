/*
  J3.ino - SCARA axis firmware
  Encoder wiring used here:
    AS5600 SCL -> A4
    AS5600 SDA -> A5
    Photo interrupter OUT -> D13
  Commands: GOTO,<steps> / SPEED,<steps_per_sec> / ACCEL,<steps_per_sec2>
            STOP / HOME / HOME_SEARCH,<dir>,<speed>
  Reports:  J3 READY / ENC,<raw>,<limit> / HOME_DONE,<raw>,<limit>
*/

#include <AccelStepper.h>

#define PIN_STEP  9
#define PIN_DIR   10
#define PIN_ENA   11
#define PIN_LIMIT 13
#define PIN_SCL   A4
#define PIN_SDA   A5
#define PIN_SCL_ALT A5
#define PIN_SDA_ALT A4
#define AS5600_ADDR  0x36
#define REG_ANGLE_H  0x0E

AccelStepper stepper(AccelStepper::DRIVER, PIN_STEP, PIN_DIR);

String cmdBuf = "";
bool enabled = false;
bool homing = false;
int homeDir = -1;
float liveSpeed = 1000;
float liveAccel = 1500;
unsigned long lastEncMs = 0;
const unsigned long ENC_INTERVAL = 100;
const long HOME_TRAVEL_STEPS = 120000L;

void enableDriver(bool on) {
  digitalWrite(PIN_ENA, on ? LOW : HIGH);
  enabled = on;
}

uint8_t activeScl = PIN_SCL;
uint8_t activeSda = PIN_SDA;

void useI2CPins(uint8_t scl, uint8_t sda) {
  activeScl = scl;
  activeSda = sda;
}

void sdaHigh() { pinMode(activeSda, INPUT_PULLUP); }
void sdaLow()  { pinMode(activeSda, OUTPUT); digitalWrite(activeSda, LOW); }
void sclHigh() { pinMode(activeScl, INPUT_PULLUP); }
void sclLow()  { pinMode(activeScl, OUTPUT); digitalWrite(activeScl, LOW); }

void i2cDelay() { delayMicroseconds(5); }

void softI2CStart() {
  sdaHigh(); sclHigh(); i2cDelay();
  sdaLow(); i2cDelay();
  sclLow(); i2cDelay();
}

void softI2CStop() {
  sdaLow(); i2cDelay();
  sclHigh(); i2cDelay();
  sdaHigh(); i2cDelay();
}

bool softI2CWrite(uint8_t value) {
  for (int i = 7; i >= 0; --i) {
    if (value & (1 << i)) sdaHigh();
    else sdaLow();
    i2cDelay();
    sclHigh(); i2cDelay();
    sclLow(); i2cDelay();
  }
  sdaHigh();
  i2cDelay();
  sclHigh(); i2cDelay();
  bool ack = (digitalRead(activeSda) == LOW);
  sclLow(); i2cDelay();
  return ack;
}

uint8_t softI2CRead(bool ack) {
  uint8_t value = 0;
  sdaHigh();
  for (int i = 7; i >= 0; --i) {
    sclHigh(); i2cDelay();
    if (digitalRead(activeSda)) value |= (1 << i);
    sclLow(); i2cDelay();
  }
  if (ack) sdaLow();
  else sdaHigh();
  i2cDelay();
  sclHigh(); i2cDelay();
  sclLow(); i2cDelay();
  sdaHigh();
  return value;
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_ENA, OUTPUT);
  pinMode(PIN_LIMIT, INPUT_PULLUP);
  sdaHigh();
  sclHigh();
  enableDriver(false);
  stepper.setMaxSpeed(liveSpeed);
  stepper.setAcceleration(liveAccel);
  stepper.setCurrentPosition(0);
  Serial.println("J3 READY");
}

void loop() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n') { processCmd(cmdBuf); cmdBuf = ""; }
    else if (c != '\r') cmdBuf += c;
  }

  if (homing && digitalRead(PIN_LIMIT) == LOW) {
    finishHome();
  }

  if (enabled) stepper.run();

  unsigned long now = millis();
  if (now - lastEncMs >= ENC_INTERVAL) {
    lastEncMs = now;
    sendEncoder();
  }
}

int readAS5600WithPins(uint8_t scl, uint8_t sda) {
  useI2CPins(scl, sda);
  sdaHigh();
  sclHigh();
  softI2CStart();
  if (!softI2CWrite((AS5600_ADDR << 1) | 0)) {
    softI2CStop();
    return -1;
  }
  if (!softI2CWrite(REG_ANGLE_H)) {
    softI2CStop();
    return -1;
  }
  softI2CStart();
  if (!softI2CWrite((AS5600_ADDR << 1) | 1)) {
    softI2CStop();
    return -1;
  }
  uint8_t hi = softI2CRead(true);
  uint8_t lo = softI2CRead(false);
  softI2CStop();
  return ((hi & 0x0F) << 8) | lo;
}

int readAS5600() {
  int raw = readAS5600WithPins(PIN_SCL, PIN_SDA);
  if (raw >= 0) return raw;
  return readAS5600WithPins(PIN_SCL_ALT, PIN_SDA_ALT);
}

void sendEncoder() {
  int raw = readAS5600();
  int limitVal = digitalRead(PIN_LIMIT);
  Serial.print("ENC,");
  Serial.print(raw);
  Serial.print(",");
  Serial.println(limitVal);
}

void finishHome() {
  homing = false;
  stepper.stop();
  stepper.setCurrentPosition(0);
  enableDriver(false);
  int raw = readAS5600();
  int limitVal = digitalRead(PIN_LIMIT);
  Serial.print("HOME_DONE,");
  Serial.print(raw);
  Serial.print(",");
  Serial.println(limitVal);
}

void processCmd(String cmd) {
  cmd.trim();
  if (cmd.length() == 0) return;

  if (cmd.startsWith("GOTO,")) {
    homing = false;
    long target = cmd.substring(5).toInt();
    enableDriver(true);
    stepper.moveTo(target);
    Serial.print("GOTO Target: ");
    Serial.print(target);
    Serial.print(" (Dir Pin: ");
    Serial.print(digitalRead(PIN_DIR));
    Serial.println(")");
  } else if (cmd.startsWith("SPEED,")) {
    liveSpeed = cmd.substring(6).toFloat();
    if (liveSpeed < 1.0) liveSpeed = 1.0;
    stepper.setMaxSpeed(liveSpeed);
  } else if (cmd.startsWith("ACCEL,")) {
    liveAccel = cmd.substring(6).toFloat();
    if (liveAccel < 1.0) liveAccel = 1.0;
    stepper.setAcceleration(liveAccel);
  } else if (cmd == "STOP") {
    homing = false;
    stepper.stop();
    enableDriver(false);
  } else if (cmd == "HOME") {
    stepper.setCurrentPosition(0);
  } else if (cmd.startsWith("HOME_SEARCH")) {
    int firstComma = cmd.indexOf(',');
    int secondComma = cmd.indexOf(',', firstComma + 1);
    homeDir = -1;
    if (firstComma >= 0) {
      String dirStr = (secondComma > firstComma) ? cmd.substring(firstComma + 1, secondComma) : cmd.substring(firstComma + 1);
      homeDir = dirStr.toInt() < 0 ? -1 : 1;
    }
    if (secondComma > firstComma) {
      liveSpeed = cmd.substring(secondComma + 1).toFloat();
      if (liveSpeed < 1.0) liveSpeed = 1.0;
      stepper.setMaxSpeed(liveSpeed);
    }
    enableDriver(true);
    homing = true;
    stepper.moveTo(stepper.currentPosition() + (homeDir * HOME_TRAVEL_STEPS));
  }
}
